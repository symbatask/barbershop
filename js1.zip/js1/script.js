// let a = 40
// a = 41
// let b = 49
// a = a + b
// console.log(a)
// console.log("a")
// let pi = 3.14
// pi = 3.14
// console.log(pi)
// let num1 = 33
// let num2 = 4
// let sum = num1 + num2
// let sub = num1 - num2
// let multiply = num1 * num2
// let division = num1 / num2
// let remainder = num1 % num2
// console.log(sum,sub,multiply,division,remainder)
// let age = 25
// console.log(typeof  age)
// let name = "Garry"
// console.log(typeof name)
// let surname = "Potter"
// console.log(typeof surname)
// let fullName = name + " " + surname
// console.log(fullName)
// let username = "Igor"
// // let greeting = "Welcome , " + username + " !"
// let greeting = `Welcome, ${username}!`
// // console.log(greeting)
// // let x = 55
// // let y = " Ivan"
// // let result = x + y
// // console.log(result)
// let x = 55
// let y = " 100"
// let result = x + y
// console.log(result)


// .task-1
    //  1. Вам дана переменная num, присвойте ей значение. Выведите значение этой переменной в консоль.

// let a = 33
// console.log(a)
// .task-2
//  2. Вам даны переменные a=10, b=2 и c=5. Выведите в консоль их сумму.

// let a=10
// let b=2
// let c=5
// let sum = a + b + c
// console.log(sum)
// .task-2
//  3. Вам дана переменная со значением 100, выведите в консоль умноженную переменную на 2.
// let a = 100
// let a = 100 * 2
// console.log(a)
// .task-4
// 4. Вам дана переменная со значением 67. Выведите в консоль остаток деления на цело.
// let a = 67
// let b = 11
// let remainder = a % b
// console.log(remainder)
// task-5
// 5. Вам даны переменные a=10 и b=2. Выведите в консоль их сумму, разность, произведение и частное (результат деления).
// let a = 10
// let b = 2
// let sum = a + b
// let sub = a - b
// let multiply = a * b
// let division = a / b
// console.log(sum, sub, multiply, division)
// task-6
// 6. Вам даны переменные c=15 и d=2. Просуммируйте их, а результат присвойте переменной result. Выведите в консоль значение переменной result.
// let c = 15
// let d = 2
// result = c + d
// console.log(result)
// task-7
// 7. Вам даны переменные a=30, и b=15 Сложите переменные a и c и результат присвойте переменной c. Затем выведите в консоль остаток деления на цело переменной
// let a = 30
// let b = 15
// c = a + b
// c = c % a
// console.log(c)
// task-8
// 8. Вам даны переменные a=17 и b=10. Отнимите от a переменную b и результат присвойте переменной c. Затем создайте переменную d,
//     присвойте ей значение. Сложите переменные c и d, а результат запишите в переменную result.
//
//     Выведите в консоль значение переменной result.
//     let a = 17
// let b = 10
// let c = a - b
//let  d = 10
// let result = c + d
// console.log(result)
// task-9
// 9. Вам даны a='10' и b='99'. Присвойте результат переменной result и выведите её в консоль.
//     let a = 10
// let b = 99
// result = a - b
// console.log(result)
// task-10
// 10. Вам даны переменные name='Аскар', number=10. Сложите данные переменные, присвойте результат переменной result и выведите её в консоль.

// let name = " Аскар "
// let number = 10
//
// let result = name + number
// console.log(result)
// task-11
// 1. Вам дана переменная str, присвойте ей значение 'Привет, Мир!'. Выведите значение этой переменной в консоль.
// let str = "Привет, Мир!"
// console.log(str)
// task-12
// 2. Вам даны переменные str1='Привет, ' и str2='Мир!'. С помощью этих переменных и операции сложения строк выведите в консоль фразу 'Привет, Мир!'.
// let str1='Привет'
// let str2='Мир!'
//
//  let fullName = str1 + " " + str2
//  console.log(fullName)

// task-13
// 13. Вам дана переменная name, присвойте ей ваше имя. Выведите в консоль фразу 'Привет, *Имя*!'.
// let username = "Igor"
// let greeting = `Привет, ${username}!`
//  console.log(greeting)
// task-14
// 4. Вам дана переменная age , присвойте ей ваш возраст. Выведите в консоль 'Мне *Возраст* лет!'.
//     let age = 25
// let aging = `Мне, ${age} лет!`
//  console.log(aging)
// task-15
// 5. Вам даны четыре переменные.
//     Первая - для хранения количества дней. Присвойте ей значение "365".
//     Вторая - для хранения названия нашей планеты "Земля".
//     Третья - для хранения примерного количества жителей нашей планеты. Присвойте ей значение "7 млрд.".
//     Четвертая - для хранения слова "Солнце".
//     Далее, используя текст и переменные, нужно вывести в консоль такой абзац:
//     "В нашем году 365 дней. Днём у нас светит Солнце. Население планеты Земля составляет примерно 7 млрд. человек."
// let a = 365
// let b = "Земля"
// let c = "7 млрд."
// let d = "Солнце"
// let content = `В нашем году, ${a} дней. Днём у нас светит ${d} . Население планеты ${b} Земля составляет примерно  ${c} человек.`
// console.log(content)
// task-16
// 1. Вам дана переменная a=50. Выведите в консоль тип значения этой переменной.
// let a = 50
// let a = 10
// let b = 35
// let result = `${a} + ${b}`
// console.log(typeof result)
// task-18
// 3. Вам дана переменная a=10, выведите в консоль тип этой переменной - string.
// let a = 10
// let result = `${a}`
// console.log(typeof result)
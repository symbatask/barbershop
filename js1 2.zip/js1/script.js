// let a = 40
// a = 41
// let b = 49
// a = a + b
// console.log(a)
// console.log("a")
// let pi = 3.14
// pi = 3.14
// console.log(pi)
// let num1 = 33
// let num2 = 4
// let sum = num1 + num2
// let sub = num1 - num2
// let multiply = num1 * num2
// let division = num1 / num2
// let remainder = num1 % num2
// console.log(sum,sub,multiply,division,remainder)
// let age = 25
// console.log(typeof  age)
// let name = "Garry"
// console.log(typeof name)
// let surname = "Potter"
// console.log(typeof surname)
// let fullName = name + " " + surname
// console.log(fullName)
// let username = "Igor"
// // let greeting = "Welcome , " + username + " !"
// let greeting = `Welcome, ${username}!`
// // console.log(greeting)
// // let x = 55
// // let y = " Ivan"
// // let result = x + y
// // console.log(result)
// let x = 55
// let y = " 100"
// let result = x + y
// console.log(result)


// .task-1
//  1. Вам дана переменная num, присвойте ей значение. Выведите значение этой переменной в консоль.

// let a = 33
// console.log(a)
// .task-2
//  2. Вам даны переменные a=10, b=2 и c=5. Выведите в консоль их сумму.

// let a=10
// let b=2
// let c=5
// let sum = a + b + c
// console.log(sum)
// .task-2
//  3. Вам дана переменная со значением 100, выведите в консоль умноженную переменную на 2.
// let a = 100
// let a = 100 * 2
// console.log(a)
// .task-4
// 4. Вам дана переменная со значением 67. Выведите в консоль остаток деления на цело.
// let a = 67
// let b = 11
// let remainder = a % b
// console.log(remainder)
// task-5
// 5. Вам даны переменные a=10 и b=2. Выведите в консоль их сумму, разность, произведение и частное (результат деления).
// let a = 10
// let b = 2
// let sum = a + b
// let sub = a - b
// let multiply = a * b
// let division = a / b
// console.log(sum, sub, multiply, division)
// task-6
// 6. Вам даны переменные c=15 и d=2. Просуммируйте их, а результат присвойте переменной result. Выведите в консоль значение переменной result.
// let c = 15
// let d = 2
// result = c + d
// console.log(result)
// task-7
// 7. Вам даны переменные a=30, и b=15 Сложите переменные a и c и результат присвойте переменной c. Затем выведите в консоль остаток деления на цело переменной
// let a = 30
// let b = 15
// c = a + b
// c = c % a
// console.log(c)
// task-8
// 8. Вам даны переменные a=17 и b=10. Отнимите от a переменную b и результат присвойте переменной c. Затем создайте переменную d,
//     присвойте ей значение. Сложите переменные c и d, а результат запишите в переменную result.
//
//     Выведите в консоль значение переменной result.
//     let a = 17
// let b = 10
// let c = a - b
//let  d = 10
// let result = c + d
// console.log(result)
// task-9
// 9. Вам даны a='10' и b='99'. Присвойте результат переменной result и выведите её в консоль.
//     let a = 10
// let b = 99
// result = a - b
// console.log(result)
// task-10
// 10. Вам даны переменные name='Аскар', number=10. Сложите данные переменные, присвойте результат переменной result и выведите её в консоль.

// let name = " Аскар "
// let number = 10
//
// let result = name + number
// console.log(result)
// task-11
// 1. Вам дана переменная str, присвойте ей значение 'Привет, Мир!'. Выведите значение этой переменной в консоль.
// let str = "Привет, Мир!"
// console.log(str)
// task-12
// 2. Вам даны переменные str1='Привет, ' и str2='Мир!'. С помощью этих переменных и операции сложения строк выведите в консоль фразу 'Привет, Мир!'.
// let str1='Привет'
// let str2='Мир!'
//
//  let fullName = str1 + " " + str2
//  console.log(fullName)

// task-13
// 13. Вам дана переменная name, присвойте ей ваше имя. Выведите в консоль фразу 'Привет, *Имя*!'.
// let username = "Igor"
// let greeting = `Привет, ${username}!`
//  console.log(greeting)
// task-14
// 4. Вам дана переменная age , присвойте ей ваш возраст. Выведите в консоль 'Мне *Возраст* лет!'.
//     let age = 25
// let aging = `Мне, ${age} лет!`
//  console.log(aging)
// task-15
// 5. Вам даны четыре переменные.
//     Первая - для хранения количества дней. Присвойте ей значение "365".
//     Вторая - для хранения названия нашей планеты "Земля".
//     Третья - для хранения примерного количества жителей нашей планеты. Присвойте ей значение "7 млрд.".
//     Четвертая - для хранения слова "Солнце".
//     Далее, используя текст и переменные, нужно вывести в консоль такой абзац:
//     "В нашем году 365 дней. Днём у нас светит Солнце. Население планеты Земля составляет примерно 7 млрд. человек."
// let a = 365
// let b = "Земля"
// let c = "7 млрд."
// let d = "Солнце"
// let content = `В нашем году, ${a} дней. Днём у нас светит ${d} . Население планеты ${b} Земля составляет примерно  ${c} человек.`
// console.log(content)
// task-16
// 1. Вам дана переменная a=50. Выведите в консоль тип значения этой переменной.
// let a = 50
// let a = 10
// let b = 35
// let result = `${a} + ${b}`
// console.log(typeof result)
// task-18
// 3. Вам дана переменная a=10, выведите в консоль тип этой переменной - string.
// let a = 10
// let result = `${a}`
// console.log(typeof result)
// transform to string############
// let str = "Ivan hello my friend"
// console.log(str[7])
// console.log(str.length)
// console.log(str.length - 1)
// console.log(str [str.length - 1])
// let num = 10
// console.log(num + " ")
// console.log(String(num))
// console.log(num.toString())
// // transform to num
// let str = "10.5"
// console.log(Number(str))
// console.log(parseInt(str))
// console.log(+str)

// is it number ##########
// let number = 100
// console.log(isNaN(number))
// let str = "100"
// console.log(isNaN(str))
// match###############
// let a = 20
// let b = 20
// console.log(a > b)
// console.log(a < b)
// console.log(a >= b)
// console.log(a <= b)
// compares inner
// console.log(a == b)
// compares inner and type
// console.log(a === b)
// not equal
// console.log(a !== b)
// boolean######
// let val = true
// let isAdmin = false
// console.log(typeof isAdmin)
// let isAdmin = false
// console.log(!isAdmin)
// console.log(!true)
// let today = 18
// let birthday = 18
// if (today === birthday) {
//     console.log("Happy birthday,Olya!")
// } else if (today < birthday) {
//     console.log("it is a bit early")
// } else {
//     console.log("it is a bit late")
// }
// let num1 = 10
// let num2 = 10
// let num3 = 10
// if(num1 === num2 && num1 === num3){
//     console.log("everything is equal")
// } else {
//     console.log("it is not equal")
// }
// // коньюнкция / логическое умножение 1*0*1*1*1
// console.log(true === true && false === true )
// // дизьюнкция / логическое сложение 1+1+0+1
// console.log(true === true || false === true )
// console.log(true || false)
// let time = -100
//
// if (time > 0 && time <= 15) {
//     console.log("First quoter")
// } else if (time <= 30 && time >15) {
//     console.log("Second quoter")
// } else if (time <= 45 && time >30) {
//     console.log("Third quoter")
// }
// else if (time <= 60 && time >45) {
//     console.log("forth quoter")
// }
// else{
//     console.log("invalid value")
// }
// Home work################################################
// task-1 1. Вам дана переменная a. Если переменная a равна 10, то выведите 'Верно', иначе выведите 'Неверно'.
// a = 11
// if (a === 10) {
//    console.log('Верно') }
//     else{
//         console.log('Неверно')
// }
// task-2
// 2. Вам даны две переменные a=50, b=100. Составьте условие, по которому в консоль будет выводиться 'a больше b', 'a меньше b'.
// let a = 50
// let b = 100
// console.log(a > b )
// task-3
// 3. Вам дана переменная a=-2. Составьте условие, по которому в консоль будет выводиться 'positive' - если число больше 0, 'равно'
// если число равно 0, "negative" если число меньше 0.
// let a = -2
// if (a > 0 ) {
//     console.log('positive')
// } else if (a === 0 ) {
//     console.log('равно')
// }
// else{
//     console.log("negative")
// }
// task-4
// 4. Вам дана переменная number=45. Составьте условие, по которому будет выводиться в консоль "Четное число", "Нечетное число".
// number = 45
// if (number % 2 === 0 ) {
//     console.log("Четное число")
// } else  {
//     console.log("Нечетное число")
// }
// task-5
// 5. Вам даны две переменные a=10, b=2. Составьте условие, по которому,
//     остаток деления a на b, будет выводиться консоль "Четное число", "Нечетное число".
// a = 10
// b = 2
// if (a % b  === 0 ) {
//     console.log("Четное число")
// }
//
// else  {
//     console.log("Нечетное число")
// }
// task-6
// 6. Вам дана переменная s. Составьте условие, по которому в консоль
// будет выводится тип этой переменной - "boolean", "number", "string".
//    let s = 6
// console.log(typeof  s)
// let s = "Kamil"
// console.log(typeof  s)
// let s = false
// console.log(typeof  s)
// task-7
// 7. Вам дана переменная а. Если переменная a больше одного и меньше 9-ти, то выведите 'Верно', иначе выведите 'Неверно'.
// let a = 3
// if (a > 1 && a < 9 ) {
//     console.log('Верно')
// } else {
//     console.log('Неверно')
// }
// task-8
// 8. Вам дана переменная а. Если переменная a равна трем или равна семи,
//     то прибавьте к ней 7, иначе поделите ее на 10. Выведите новое значение переменной в консоль.
//
// let a = 7
// if (a === 3 || a === 7 ) {
//     console.log(a + 7)
// } else {
//     console.log(a / 10)
// }
// task-9
// 9. Вам даны переменные а , b. Если переменная a равна или меньше 0, а переменная b больше или равна 5,
//     то выведите сумму этих переменных, иначе выведите их разность (результат вычитания).
// let a = 7
// let b = 8
// if (a <= 0 && b >= 5 ) {
//     console.log(a + b)
// } else {
//     console.log(a - b)
// }
// task-10
// 10. Вам даны переменные a , b. Если переменная a больше 4-х и меньше 10-ти,
//     или переменная b больше или равна 7-ми и меньше 17-ти, то выведите 'Верно',
//     в противном случае выведите 'Неверно'.
// let a = 32
// let b = 6
// if ((a >= 4 && a <= 10 ) || (b >= 7 && b <= 17)) {
//     console.log('Верно')
// } else {
//     console.log('Неверно')
// }
// task-11
// 11. Вам дана переменная month. В ней лежит какое-то число из интервала от 1 до 12.
// Определите в какую пору года попадает этот месяц (зима, лето, весна, осень).
// month = 12
// if ((month > 0 && month <= 2) || month === 12){
//     console.log("winter")
// } else if (month > 2 && month <=5) {
//     console.log("spring")
// } else if (month > 5 && month <=8) {
//     console.log("summer")
// }
// else if (month > 8 && month <= 11) {
//     console.log("autumn")
// }
// else{
//     console.log("invalid value")
// }
// task-12
// 12. Вам дана переменная day. В ней лежит какое-то число из интервала от 1 до 31.
// Определите в какую декаду месяца попадает это число (в первую, вторую или третью).
// day = 12
// if (day > 0 && day <= 10) {
//     console.log("first decade")
// } else if (day > 10 && day <=20) {
//     console.log("second decade")
// } else if (day > 20 && day <=31) {
//     console.log("third decade")
// }
// else{
//     console.log("invalid value")
// }
// task-13
// 13. Вам дана переменная a='12345'. Проверьте, что первым символом этой переменной является цифра 1, 2 или 3.
// Если это так – выведите ‘да’, в противном случае выведите ‘нет’.
// let a='12345'
// if (a[0] == 1 || a[0] == 2 || a[0] == 3) {
//     console.log("да")
// } else  {
//     console.log("нет")
// }
// task-14
// 14. Вам дана переменная age=*любое двузначное число*. Составьте условие, по которому,
//     в консоль будет выводиться "Мне ** год", "Мне ** лет", в зависимости от возраста. Наример мне 21 год, мне 20 лет.
// a = 20
// if (a%10 <=4  && a%10 > 1) {
//     console.log(`Мне ${a} года`)
// }
// else if(a%10 === 1) {
//     console.log(`Мне ${a} год`)
// }
// else if(a%10 === 0) {
//     console.log(`Мне ${a} лет `)
// }
// else  {
//     console.log(`Мне ${a} лет`)
// }
//     task-15
// 15. Вам дана переменная time= *любое чило от 1 до 59*. Составьте условие, по которому время будет делиться на четверти.
//     Пример: time = 12 - Первая четверть. Если число больше 60, то в консоли будет выдаваться "Неверное число".
// let time = 15
// if (time > 0 && time <= 15) {
//     console.log("First quoter")
// } else if (time <= 30 && time >15) {
//     console.log("Second quoter")
// } else if (time <= 45 && time >30) {
//     console.log("Third quoter")
// }
// else if (time <= 60 && time >45) {
//     console.log("forth quoter")
// }
// else{
//     console.log("invalid value")
// }

